module.exports = {
  'env': {
    'node': true
  },
  'parserOptions': {
    'sourceType': 'module'
  },
  'rules': {
    'no-console': 0,
  }
};
