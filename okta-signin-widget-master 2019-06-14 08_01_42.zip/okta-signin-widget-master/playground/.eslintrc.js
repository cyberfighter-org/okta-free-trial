module.exports = {
  'env': {
    'node': true
  },
  'parserOptions': {
    'sourceType': 'module'
  }
};
