define({
  "status": 400,
  "responseType": "json",
  "response": {
    "errorCode": "E0000087",
    "errorSummary": "The recovery question answer did not match our records.",
    "errorLink": "E0000087",
    "errorId": "oaelYrw2A4AThiuqrb4UhGdUg",
    "errorCauses": [

    ]
  }
});
