define({
  "status": 200,
  "responseType": "json",
  "response": {
    result: 'success',
    pwdImg: '/base/test/unit/assets/1x1.gif',
    imageDescription: 'a single pixel'
  }
});
