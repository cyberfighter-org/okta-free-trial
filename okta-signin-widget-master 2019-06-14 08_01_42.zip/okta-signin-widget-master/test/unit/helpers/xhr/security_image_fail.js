define({
  "status": 200,
  "responseType": "json",
  "response": {
    result: 'success',
    pwdImg: '/img/security/unknown.png',
    imageDescription: ''
  }
});
