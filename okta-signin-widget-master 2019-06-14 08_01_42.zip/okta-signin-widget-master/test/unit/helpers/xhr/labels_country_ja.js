define({
  'status': 200,
  'responseType': 'json',
  'response': {
    'JP': 'JA: country.JP'
  }
});
