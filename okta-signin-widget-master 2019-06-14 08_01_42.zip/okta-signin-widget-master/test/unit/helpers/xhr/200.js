define({
  "status": 200,
  "responseType": "json",
  "response": {
  	stateToken: 'testStateToken'
  }
});
