define({
  'status': 200,
  'responseType': 'json',
  'response': {
    'enroll.call.setup': 'JA: enroll.call.setup',
    'security.disliked_food': 'JA: What is the food you least liked as a child?',
    'oform.errorbanner.title': 'JA: Japanese error banner title'
  }
});
