define({
  status: 401,
  responseType: 'json',
  response: {
    errorCode: 'E0000004',
    errorSummary: 'Authentication failed',
    errorLink: 'E0000004',
    errorId: 'oaehvpQ1VF-ScqAvqVqwI7Qaw',
    errorCauses: []
  }
});