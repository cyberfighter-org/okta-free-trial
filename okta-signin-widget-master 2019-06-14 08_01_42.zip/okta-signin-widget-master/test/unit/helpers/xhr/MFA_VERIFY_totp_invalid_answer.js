define({
  'status': 403,
  'responseType': 'json',
  'response': {
    'errorCode': 'E0000068',
    'errorSummary': 'Invalid Passcode\/Answer',
    'errorLink': 'E0000068',
    'errorId': 'oael69itLSMTbioahsUZ-7xiQ',
    'errorCauses': []
  }
});
