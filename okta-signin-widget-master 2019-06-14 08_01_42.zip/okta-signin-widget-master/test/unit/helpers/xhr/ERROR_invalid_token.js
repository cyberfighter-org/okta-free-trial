define({
  "status": 401,
  "responseType": "json",
  "response": {
    "errorCode": "E0000011",
    "errorSummary": "Invalid token provided",
    "errorLink": "E0000011",
    "errorId": "oaeuiUWCPr6TUSkOclgVGlWqw",
    "errorCauses": []
  }
});
