define({
  "status": 200,
  "responseType": "json",
  "response": {
    factorResult: "WAITING",
    factorType: "EMAIL",
    recoveryType: "PASSWORD",
    status: "RECOVERY_CHALLENGE"
  }
});
