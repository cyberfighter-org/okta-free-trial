define({
  "status": 400,
  "responseType": "json",
  "response": {
    "errorCode": "E0000098",
    "errorSummary": "This phone number is invalid.",
    "errorLink": "E0000098",
    "errorId": "oaeuQEaESUsSL6uFSfYluHZGw",
    "errorCauses": []
  }
});
