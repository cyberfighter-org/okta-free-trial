define({
  status: 401,
  responseType: 'text',
  response: 'Internal Server Error'
});