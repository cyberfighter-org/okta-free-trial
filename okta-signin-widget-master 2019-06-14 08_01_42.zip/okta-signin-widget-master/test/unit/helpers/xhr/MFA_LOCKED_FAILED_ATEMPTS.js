define({
  status: 403,
  responseType: 'json',
  response: {
    errorCode: 'E0000069',
    errorSummary: 'User Locked',
    errorLink: 'E0000069',
    errorId: 'oaeGLSGT-QCT_ijvM0RT6SV0A',
    errorCauses: []
  }
});