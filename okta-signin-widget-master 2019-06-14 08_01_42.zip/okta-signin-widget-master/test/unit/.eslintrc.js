module.exports = {
  'env': {
    'node': true,
    'jasmine': true
  },
  'rules': {
    'max-len': 0,
    'complexity': 0,
    'max-params': 0,
    'max-statements': 0
  }
};
