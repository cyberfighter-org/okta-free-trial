module.exports = {
  // Server / Client
  WIDGET_TEST_SERVER: '',
  WIDGET_CLIENT_ID: 'rW47c465c1wc3MKzHznu',

  // Basic user 1
  WIDGET_BASIC_USER: '',
  WIDGET_BASIC_PASSWORD: '',
  WIDGET_BASIC_NAME: 'Saml Jackson',

  // Basic user 2
  WIDGET_BASIC_USER_2: '',
  WIDGET_BASIC_PASSWORD_2: '',
  WIDGET_BASIC_NAME_2: 'Alexander Hamilton',

  // Basic user 3
  WIDGET_BASIC_USER_3: '',
  WIDGET_BASIC_PASSWORD_3: '',

  // Basic user 4
  WIDGET_BASIC_USER_4: '',
  WIDGET_BASIC_PASSWORD_4: '',

  // Basic user 5
  WIDGET_BASIC_USER_5: '',
  WIDGET_BASIC_PASSWORD_5: '',

  // FB user 1
  WIDGET_FB_USER: '',
  WIDGET_FB_PASSWORD: '',
  WIDGET_FB_NAME: 'Tom Alacddgjegbja Qinson',

  // FB user 2
  WIDGET_FB_USER_2: '',
  WIDGET_FB_PASSWORD_2: '',
  WIDGET_FB_NAME_2: 'Joe Alacchebjdhcf Bharambewitz',

  // FB user 3
  WIDGET_FB_USER_3: '',
  WIDGET_FB_PASSWORD_3: '',

};
