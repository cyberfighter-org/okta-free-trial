# AngularApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.6.3.

This serves as a test harness for `@okta/okta-signin-widget`.

```
PORT=4200
WIDGET_TEST_SERVER=http://test.okta.com
WIDGET_CLIENT_ID=xxx
yarn start
```
