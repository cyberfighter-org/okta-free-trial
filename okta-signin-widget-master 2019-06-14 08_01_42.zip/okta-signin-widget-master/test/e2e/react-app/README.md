This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

This serves as a test harness for `@okta/okta-signin-widget`.

```
PORT=3001
WIDGET_TEST_SERVER=http://test.okta.com
WIDGET_CLIENT_ID=xxx
yarn start
```