// src/Protected.js

import React from 'react';

export default () => <h3>Protected</h3>;
